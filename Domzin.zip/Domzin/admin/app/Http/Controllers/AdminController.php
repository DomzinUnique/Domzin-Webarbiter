<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Admin;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Session;
class AdminController extends Controller
{
    public function viewLogin()
    {
        return view('Login');
    }

    public function check(Request $request)
    {
        $request->validate([

            'email'=>'required',
            'password'=>'required'
        ]);

        $admin=Admin::where('email',$request->email)->first();

        if (!$admin || !Hash::check($request->password,$admin->password)) {
            
            return back()->with('failed','Invalid LogID or Password !');

        }else{

            $request->session()->put('admin',$admin);
            return redirect('/dashboard');
            
        }


    }

    public function logout()
    {
        if(session()->has('admin')){

            session()->pull('admin');
        }

        return redirect('/');
    }


    public function viewProfile()
    {
        
        return view('Profile');
    }
}
