<!doctype html>
<html  lang=""> 
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Domzin</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/normalize.css@8.0.0/normalize.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.1.3/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/font-awesome@4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/lykmapipo/themify-icons@0.1.2/css/themify-icons.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/pixeden-stroke-7-icon@1.2.3/pe-icon-7-stroke/dist/pe-icon-7-stroke.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/flag-icon-css/3.2.0/css/flag-icon.min.css">
    <link rel="stylesheet" href="{{asset('assets/css/cs-skin-elastic.css')}}">
    <link rel="stylesheet" href="{{asset('assets/css/style.css')}}">
    
    <!-- google fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@500&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@1,200&display=swap" rel="stylesheet">


   <style>

.user-area .dropdown-toggle:before {

    display: none;
}

.srch{
    position: absolute;
    top: 30px;
    left: 30px;
    color:  #888888;
}

.sr-p{
    padding-left: 40px;
}



    </style>
</head>

<body>
    <!-- Left Panel -->
    <aside id="left-panel" class="left-panel">
        <nav class="navbar navbar-expand-sm navbar-default">
            <div id="main-menu" class="main-menu collapse navbar-collapse">
                <ul class="nav navbar-nav">
                    <form class="px-3 my-4">
                        <input type="search" class="form-control sr-p" placeholder="Search"> <span class="srch"><i class="fa  fa-search"></i></span>
                    </form>
                    <li class="active">
                        <a class="dsh-clr " href="index.html"><i class="menu-icon fa fa-th-large ml-3 text-white"></i>Dashboard </a>
                    </li>
                    <!-- <li class="menu-title">UI elements</li> -->
                    <li class="menu-item-has-children dropdown m-bg ">
                        <a href="#" class="dropdown-toggle m-clr" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                             <i class="menu-icon fa fa-cogs"></i> Analytics</a>
                        <ul class="sub-menu children dropdown-menu">
                            <li><i class="fa fa-puzzle-piece"></i><a href="analytics_commission report.html">Commission Report</a></li>
                            <li><i class="fa fa-id-badge"></i><a href="analytics_progress_data.html">Progress Report</a></li>
                            <li><i class="fa fa-bars"></i><a href="analytics_payout_data.html">Payout Data</a></li>
                        </ul>
                    </li>
                    <li>
                        <a href="activeuserdata.html" class="m-clr"><i class="menu-icon fa fa-th-large"></i>Active User Data</a>
                    </li>

                    <li>
                        <a href="order.html" class="m-clr"><i class="menu-icon fa fa-th-large"></i>Orders</a>
                    </li>

                    <li class="menu-item-has-children dropdown m-bg">
                        <a href="#" class="dropdown-toggle m-clr" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> <i class="menu-icon fa fa-table"></i>Approvals</a>
                        <ul class="sub-menu children dropdown-menu">
                            <li><i class="fa fa-table"></i><a href="approvals_store.html">Store Approvals</a></li>
                            <li><i class="fa fa-table"></i><a href="approvals_product.html">Products Approvals</a></li>
                            <li><i class="fa fa-table"></i><a href="#">KYC Documents</a></li>
                        </ul>
                    </li>
                    

                    <li>
                        <a class="m-clr" href="#"><i class="menu-icon fa fa-th-large"></i>Support</a>
                    </li>

                    <!-- <li>
                        <a href="#"><i class="menu-icon fa fa-th-large"></i>App Management</a>
                    </li> -->
                    <li class=" m-clr">App Management</li><!-- /.menu-title -->

                    <li class="menu-item-has-children dropdown m-bg">
                        <a href="#" class="dropdown-toggle m-clr" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> <i class="menu-icon fa fa-tasks"></i>Manage Stores</a>
                        <ul class="sub-menu children dropdown-menu">
                            <li><i class="menu-icon ti-themify-logo"></i><a href="manage-store_all-store.html"> All Stores</a></li>
                            <li><i class="menu-icon fa fa-fort-awesome"></i><a href="manage_stores_create-new Store.html">Create New Stores</a></li>
                            <li><i class="menu-icon ti-themify-logo"></i><a href="#">Stores Approvals</a></li>
                            <li><i class="menu-icon fa fa-fort-awesome"></i><a href="#">Store Payout History</a></li>
                            <li><i class="menu-icon ti-themify-logo"></i><a href="#">Store Payout Reminder</a></li>
                            <li><i class="menu-icon fa fa-fort-awesome"></i><a href="#">Payout Status</a></li>
                            <li><i class="menu-icon ti-themify-logo"></i><a href="#">Stores Growth Report</a></li>
                        </ul>
                    </li>
                    
                    <li class="menu-item-has-children dropdown m-bg">
                        <a href="#" class="dropdown-toggle m-clr" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> <i class="menu-icon fa fa-bar-chart"></i>Categories</a>
                        <ul class="sub-menu children dropdown-menu">
                            <li><i class="menu-icon fa fa-line-chart"></i><a href="category_field-category.html">Create Category Field</a></li>
                            <li><i class="menu-icon fa fa-area-chart"></i><a href="#">Create Categories</a></li>
                            <li><i class="menu-icon fa fa-pie-chart"></i><a href="#">Create Sub Categories</a></li>
                        </ul>
                    </li>

                    <li class="menu-item-has-children dropdown m-bg">
                        <a href="#" class="dropdown-toggle m-clr" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> <i class="menu-icon fa fa-area-chart"></i>Product</a>
                        <ul class="sub-menu children dropdown-menu">
                            <li><i class="menu-icon fa fa-map-o"></i><a href="#">Add New Product</a></li>
                            <li><i class="menu-icon fa fa-street-view"></i><a href="#">Search  Product</a></li>
                        </ul>
                    </li>
                    
                    <li class="menu-item-has-children dropdown m-bg">
                        <a href="#" class="dropdown-toggle m-clr" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> <i class="menu-icon fa fa-glass"></i>Coupons</a>
                        <ul class="sub-menu children dropdown-menu">
                            <li><i class="menu-icon fa fa-sign-in"></i><a href="#">Create Promocodes</a></li>
                            <li><i class="menu-icon fa fa-sign-in"></i><a href="#">Create Store Offers</a></li>
                        </ul>
                    </li>

                    <li class="menu-item-has-children dropdown m-bg">
                        <a href="#" class="dropdown-toggle m-clr" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> <i class="menu-icon fa fa-glass"></i>Promotions</a>
                        <ul class="sub-menu children dropdown-menu">
                            <li><i class="menu-icon fa fa-sign-in"></i><a href="#">Home Page Banners</a></li>
                            <li><i class="menu-icon fa fa-sign-in"></i><a href="#">Store List Banners</a></li>
                        </ul>
                    </li>

                    <li class="menu-item-has-children dropdown m-bg">
                        <a href="#" class="dropdown-toggle m-clr" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> <i class="menu-icon fa fa-glass"></i>Roles</a>
                        <ul class="sub-menu children dropdown-menu">
                            <li><i class="menu-icon fa fa-sign-in"></i><a href="#">Sub-Admin</a></li>
                            <li><i class="menu-icon fa fa-sign-in"></i><a href="#">City Admin</a></li>
                            <li><i class="menu-icon fa fa-sign-in"></i><a href="#">Zonal Admin</a></li>
                        </ul>
                    </li>

                    <li class="menu-item-has-children dropdown m-bg">
                        <a href="#" class="dropdown-toggle m-clr" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> <i class="menu-icon fa fa-bar-chart"></i>Field Payout</a>
                        <ul class="sub-menu children dropdown-menu">
                            <li><i class="menu-icon fa fa-line-chart"></i><a href="field-payout_all-field-boy.html">Create Field Boy  </a></li>
                            <li><i class="menu-icon fa fa-area-chart"></i><a href="#">Field Payout Reminder</a></li>
                            <li><i class="menu-icon fa fa-pie-chart"></i><a href="#">Payout  Status</a></li>
                            <li><i class="menu-icon fa fa-pie-chart"></i><a href="#">Field Progress Report</a></li>
                        </ul>
                    </li>

                    <li class="menu-item-has-children dropdown m-bg">
                        <a href="#" class="dropdown-toggle m-clr" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> <i class="menu-icon fa fa-bar-chart"></i>Terms & Con.</a>
                        <ul class="sub-menu children dropdown-menu">
                            <li><i class="menu-icon fa fa-line-chart"></i><a href="terms&conditions.html">Terms & condition </a></li>
                            <li><i class="menu-icon fa fa-area-chart"></i><a href="privacy-policy.html">Privacy Policy</a></li>
                            <li><i class="menu-icon fa fa-area-chart"></i><a href="faq.html">FAQ</a></li>
                        </ul>
                    </li>

                    <!--<li class="menu-title">Settings</li> --><!-- /.menu-title -->
                    <li class="m-clr">Settings</li>

                    <li class="menu-item-has-children dropdown m-bg">
                        <a href="#" class="dropdown-toggle m-clr" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> <i class="menu-icon fa fa-bar-chart"></i>App Settings</a>
                        <ul class="sub-menu children dropdown-menu">
                            <li><i class="menu-icon fa fa-line-chart"></i><a href="settings_home-screen.html">Home Screen Settings</a></li>
                            <li><i class="menu-icon fa fa-area-chart"></i><a href="settings_slider-settings.html">Sliders Settings</a></li>
                            <li><i class="menu-icon fa fa-pie-chart"></i><a href="app-settings_app-store-offer-notification.html">App Notifications</a></li>
                        </ul>
                    </li>

                    <li class="menu-item-has-children dropdown m-bg">
                        <a href="#" class="dropdown-toggle m-clr" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> <i class="menu-icon fa fa-bar-chart"></i>Payments</a>
                        <ul class="sub-menu children dropdown-menu">
                            <li><i class="menu-icon fa fa-line-chart"></i><a href="#">Set Payment Gateway</a></li>
                        </ul>
                    </li>

                    <li>
                        <a class="m-clr" href="#"><i class="menu-icon fa fa-th-large"></i>Medias Library</a>
                    </li>

                    <li class="menu-item-has-children dropdown m-bg">
                        <a href="#" class="dropdown-toggle m-clr" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> <i class="menu-icon fa fa-bar-chart"></i>Settings</a>
                        <ul class="sub-menu children dropdown-menu">
                            <li><i class="menu-icon fa fa-line-chart"></i><a href="settings_permission.html"> Permissions</a></li>
                            <li><i class="menu-icon fa fa-line-chart"></i><a href="settings_push-notification.html">Push Notifications</a></li>
                            <li><i class="menu-icon fa fa-line-chart"></i><a href="settings_mail&sms-api-smpt-driver.html">Mail & SMS API</a></li>
                            <li><i class="menu-icon fa fa-line-chart"></i><a href="settings_app-notification.html">App Notifications</a></li>
                            <li><i class="menu-icon fa fa-line-chart"></i><a href="settings_cod-management-cod-list.html">COD Management</a></li>
                        </ul>
                    </li>

                </ul>
            </div><!-- /.navbar-collapse -->
        </nav>
    </aside>
    <!-- /#left-panel -->
    <!-- Right Panel -->
    <div id="right-panel" class="right-panel">
        <!-- Header-->
        <header id="header" class="header">
            <div class="top-left">
                <div class="navbar-header">
                    <a class="navbar-brand" href="/dashboard"><img src="{{asset('images/logo.png')}}" alt="Logo"></a>
                    <a class="navbar-brand hidden" href="/dashboard"><img src="{{asset('images/logo2.png')}}" alt="Logo"></a>
                    <a id="menuToggle" class="menutoggle"><i class="fa fa-bars"></i></a>
                </div>
            </div>
            <div class="top-right">
                <div class="header-menu">
                    <div class="header-left">
                        <div class="dropdown for-notification">
                            <button class="btn btn-secondary dropdown-toggle" type="button" id="notification" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <i class="fa fa-bell-o"></i>
                                <span class="count bg-danger">3</span>
                            </button>
                            <div class="dropdown-menu" aria-labelledby="notification">
                                <p class="red">You have 3 Notification</p>
                                <a class="dropdown-item media" href="#">
                                    <i class="fa fa-check"></i>
                                    <p>Server #1 overloaded.</p>
                                </a>
                                <a class="dropdown-item media" href="#">
                                    <i class="fa fa-info"></i>
                                    <p>Server #2 overloaded.</p>
                                </a>
                                <a class="dropdown-item media" href="#">
                                    <i class="fa fa-warning"></i>
                                    <p>Server #3 overloaded.</p>
                                </a>
                            </div>
                        </div>
                    </div>

                    <div class="user-area dropdown float-right">
                        <a href="#" class="dropdown-toggle active text-dark" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            <img class="user-avatar rounded-circle" src="{{asset('images/avter.png')}}" alt="User Avatar">
                            @if(Session::has('admin'))
                            <span class="ml-3">{{Session::get('admin')['fname']}}</span>
                            @endif
                        </a>

                        <div class="user-menu dropdown-menu">
                            <a class="nav-link text-dark" href="/profile"><i class="fa fa-user"></i>My Profile</a>

                            <a class="nav-link" href="/logout" style="color: #FB4040;" onclick="ask()"><i class="fa fa-power-off"></i>Logout</a>
                        </div>
                    </div>

                </div>
            </div>
        </header>
        <!-- /#header -->
        <!-- Content -->
        <div class="content">
       
            <!-- Animated -->
            <div class="animated fadeIn">
                <div class="row">
                    <div class="col-md-6">
                        <h1>Dashboard</h1>
                        </div>
                        <div class="col-md-6">
                        <nav aria-label="breadcrumb">
                            <ol class="breadcrumb justify-content-end bg-transparent">
                              <li class="breadcrumb-item"><a href="#">Dashboard</a></li>
                              <li class="breadcrumb-item active" aria-current="page">Dashboard</li>
                            </ol>
                          </nav>
                    </div>
                </div>
                <!-- Widgets  -->
                <div class="row">
                    <div class="col-lg-3 col-md-6">
                        <div class="card" style="background-color: #3aee8d; box-shadow: 0px 2px 20px rgba(136, 136, 136, 0.25);
                        border-radius: 9px;">
                            <div class="card-body">
                                <div class="stat-widget-five">
                                    <div class="stat-icon dib flat-color-1">
                                        <!-- <i class="pe-7s-cash"></i> -->
                                        <img src="images/rupee.png">
                                    </div>
                                    <div class="stat-content">
                                        <div class="text-left dib">
                                            <div class="stat-heading">Total Earnings</div>
                                            <div class="stat-text"><i class="fa  fa-rupee (alias)"></i>  <span class=""> 15,372</span></div>
                                            
                                        </div>
                                    </div>
                                    
                                </div>
                            </div>
                            <div class="more">
                                <a href="#">More Infos <span class="ml-2"><i class="fa  fa-arrow-circle-right"></i></span></a>
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-3 col-md-6">
                        <div class="card" style="background-color: #eb7171;  box-shadow: 0px 2px 20px rgba(136, 136, 136, 0.25);
                        border-radius: 9px;">
                            <div class="card-body">
                                <div class="stat-widget-five">
                                    <div class="stat-icon dib flat-color-1">
                                        <!-- <i class="pe-7s-cash"></i> -->
                                        <img src="images/icon2.png">
                                    </div>
                                    <div class="stat-content">
                                        <div class="text-left dib">
                                            <div class="stat-heading">Total Orders</div>
                                            <div class="stat-text">  <span class=""> 1444</span></div>
                                            
                                        </div>
                                    </div>
                                    
                                </div>
                            </div>
                            <div class="more" style="background-color: #fc4040;">
                                <a href="#">More Infos <span class="ml-2"><i class="fa  fa-arrow-circle-right"></i></span></a>
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-3 col-md-6">
                        <div class="card" style="background-color: #ffb45c;  box-shadow: 0px 2px 20px rgba(136, 136, 136, 0.25);
                        border-radius: 9px;">
                            <div class="card-body">
                                <div class="stat-widget-five">
                                    <div class="stat-icon dib flat-color-1">
                                        <!-- <i class="pe-7s-cash"></i> -->
                                        <img src="images/icon3.png">
                                    </div>
                                    <div class="stat-content">
                                        <div class="text-left dib">
                                            <div class="stat-heading">Stores</div>
                                            <div class="stat-text">  <span class=""> 120</span></div>
                                            
                                        </div>
                                    </div>
                                    
                                </div>
                            </div>
                            <div class="more" style="background-color: #f29d3a;">
                                <a href="#">More Infos <span class="ml-2"><i class="fa  fa-arrow-circle-right"></i></span></a>
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-3 col-md-6">
                        <div class="card" style="background-color: #4c65d6;  box-shadow: 0px 2px 20px rgba(136, 136, 136, 0.25);
                        border-radius: 9px;">
                            <div class="card-body">
                                <div class="stat-widget-five">
                                    <div class="stat-icon dib flat-color-1">
                                        <!-- <i class="pe-7s-cash"></i> -->
                                        <img src="images/icon4.png">
                                    </div>
                                    <div class="stat-content">
                                        <div class="text-left dib">
                                            <div class="stat-heading">Total Operational
                                                Cities</div>
                                            <div class="stat-text">  <span class=""> 120</span></div>
                                            
                                        </div>
                                    </div>
                                    
                                </div>
                            </div>
                            <div class="more" style="background-color: #41529f;">
                                <a href="#">More Infos <span class="ml-2"><i class="fa  fa-arrow-circle-right"></i></span></a>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- /Widgets -->
                <!--  Traffic  -->
               
                <!--  /Traffic -->

        
            </div>
            <!-- .animated -->
        

        </div>
        <!-- /.content -->
    
    </div>
    <!-- /#right-panel -->
    <!-- Header-->
   
    <!-- /#header -->
    
    <!-- Scripts -->
    <script src="https://cdn.jsdelivr.net/npm/jquery@2.2.4/dist/jquery.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.14.4/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.1.3/dist/js/bootstrap.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/jquery-match-height@0.7.2/dist/jquery.matchHeight.min.js"></script>
    <script src="{{asset('assets/js/main.js')}}"></script>
    <script>
    
    function ask() {
        alert('are you sure ??');
    }

    $()
    </script>
   
</body>
</html>
