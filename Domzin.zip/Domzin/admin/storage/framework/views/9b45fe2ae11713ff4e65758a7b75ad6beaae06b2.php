<!doctype html>
<html  lang=""> 
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Domzin</title>
    <meta name="description" content="Ela Admin - HTML5 Admin Template">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link rel="apple-touch-icon" href="https://i.imgur.com/QRAUqs9.png">
    <link rel="shortcut icon" href="https://i.imgur.com/QRAUqs9.png">

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/normalize.css@8.0.0/normalize.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.1.3/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/font-awesome@4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/lykmapipo/themify-icons@0.1.2/css/themify-icons.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/pixeden-stroke-7-icon@1.2.3/pe-icon-7-stroke/dist/pe-icon-7-stroke.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/flag-icon-css/3.2.0/css/flag-icon.min.css">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/cs-skin-elastic.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/style.css')); ?>">
    <!-- google fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@500&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@1,200&display=swap" rel="stylesheet">



    <!-- <script type="text/javascript" src="https://cdn.jsdelivr.net/html5shiv/3.7.3/html5shiv.min.js"></script> -->
    <link href="https://cdn.jsdelivr.net/npm/chartist@0.11.0/dist/chartist.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/jqvmap@1.5.1/dist/jqvmap.min.css" rel="stylesheet">

    <link href="https://cdn.jsdelivr.net/npm/weathericons@2.1.0/css/weather-icons.css" rel="stylesheet" />
    <link href="https://cdn.jsdelivr.net/npm/fullcalendar@3.9.0/dist/fullcalendar.min.css" rel="stylesheet" />

 
</head>

<body>
    <!-- Left Panel -->
    <aside id="left-panel" class="left-panel">
        <nav class="navbar navbar-expand-sm navbar-default">
            <div id="main-menu" class="main-menu collapse navbar-collapse">
                <ul class="nav navbar-nav">
                    <form class="px-3 my-4">
                        <input type="search" class="form-control sr-p" placeholder="Search"> <span class="srch"><i class="fa  fa-search"></i></span>
                    </form>
                    <li class="active">
                        <a class="dsh-clr " href="index.html"><i class="menu-icon fa fa-th-large ml-3 text-white"></i>Dashboard </a>
                    </li>
                    <!-- <li class="menu-title">UI elements</li> -->
                    <li class="menu-item-has-children dropdown m-bg ">
                        <a href="#" class="dropdown-toggle m-clr" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                             <i class="menu-icon fa fa-cogs"></i> Analytics</a>
                        <ul class="sub-menu children dropdown-menu">
                            <li><i class="fa fa-puzzle-piece"></i><a href="analytics_commission report.html">Commission Report</a></li>
                            <li><i class="fa fa-id-badge"></i><a href="analytics_progress_data.html">Progress Report</a></li>
                            <li><i class="fa fa-bars"></i><a href="analytics_payout_data.html">Payout Data</a></li>
                        </ul>
                    </li>
                    <li>
                        <a href="activeuserdata.html" class="m-clr"><i class="menu-icon fa fa-th-large"></i>Active User Data</a>
                    </li>

                    <li>
                        <a href="#" class="m-clr"><i class="menu-icon fa fa-th-large"></i>Orders</a>
                    </li>

                    <li class="menu-item-has-children dropdown m-bg">
                        <a href="#" class="dropdown-toggle m-clr" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> <i class="menu-icon fa fa-table"></i>Approvals</a>
                        <ul class="sub-menu children dropdown-menu">
                            <li><i class="fa fa-table"></i><a href="#">Store Approvals</a></li>
                            <li><i class="fa fa-table"></i><a href="#">Products Approvals</a></li>
                            <li><i class="fa fa-table"></i><a href="#">KYC Documents</a></li>
                        </ul>
                    </li>
                    

                    <li>
                        <a class="m-clr" href="#"><i class="menu-icon fa fa-th-large"></i>Support</a>
                    </li>

                    <!-- <li>
                        <a href="#"><i class="menu-icon fa fa-th-large"></i>App Management</a>
                    </li> -->
                    <li class=" m-clr">App Management</li><!-- /.menu-title -->

                    <li class="menu-item-has-children dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> <i class="menu-icon fa fa-tasks"></i>Manage Stores</a>
                        <ul class="sub-menu children dropdown-menu">
                            <li><i class="menu-icon fa fa-fort-awesome"></i><a href="#">Create New Stores</a></li>
                            <li><i class="menu-icon ti-themify-logo"></i><a href="#">Stores Approvals</a></li>
                            <li><i class="menu-icon fa fa-fort-awesome"></i><a href="#">Store Payout History</a></li>
                            <li><i class="menu-icon ti-themify-logo"></i><a href="#">Store Payout Reminder</a></li>
                            <li><i class="menu-icon fa fa-fort-awesome"></i><a href="#">Payout Status</a></li>
                            <li><i class="menu-icon ti-themify-logo"></i><a href="#">Stores Growth Report</a></li>
                        </ul>
                    </li>
                    
                    <li class="menu-item-has-children dropdown m-bg">
                        <a href="#" class="dropdown-toggle m-clr" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> <i class="menu-icon fa fa-bar-chart"></i>Categories</a>
                        <ul class="sub-menu children dropdown-menu">
                            <li><i class="menu-icon fa fa-line-chart"></i><a href="#">Create Category Field</a></li>
                            <li><i class="menu-icon fa fa-area-chart"></i><a href="#">Create Categories</a></li>
                            <li><i class="menu-icon fa fa-pie-chart"></i><a href="#">Create Sub Categories</a></li>
                        </ul>
                    </li>

                    <li class="menu-item-has-children dropdown m-bg">
                        <a href="#" class="dropdown-toggle m-clr" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> <i class="menu-icon fa fa-area-chart"></i>Product</a>
                        <ul class="sub-menu children dropdown-menu">
                            <li><i class="menu-icon fa fa-map-o"></i><a href="#">Add New Product</a></li>
                            <li><i class="menu-icon fa fa-street-view"></i><a href="#">Search  Product</a></li>
                        </ul>
                    </li>
                    
                    <li class="menu-item-has-children dropdown m-bg">
                        <a href="#" class="dropdown-toggle m-clr" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> <i class="menu-icon fa fa-glass"></i>Coupons</a>
                        <ul class="sub-menu children dropdown-menu">
                            <li><i class="menu-icon fa fa-sign-in"></i><a href="#">Create Promocodes</a></li>
                            <li><i class="menu-icon fa fa-sign-in"></i><a href="#">Create Store Offers</a></li>
                        </ul>
                    </li>

                    <li class="menu-item-has-children dropdown m-bg">
                        <a href="#" class="dropdown-toggle m-clr" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> <i class="menu-icon fa fa-glass"></i>Promotions</a>
                        <ul class="sub-menu children dropdown-menu">
                            <li><i class="menu-icon fa fa-sign-in"></i><a href="#">Home Page Banners</a></li>
                            <li><i class="menu-icon fa fa-sign-in"></i><a href="#">Store List Banners</a></li>
                        </ul>
                    </li>

                    <li class="menu-item-has-children dropdown m-bg">
                        <a href="#" class="dropdown-toggle m-clr" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> <i class="menu-icon fa fa-glass"></i>Roles</a>
                        <ul class="sub-menu children dropdown-menu">
                            <li><i class="menu-icon fa fa-sign-in"></i><a href="#">Sub-Admin</a></li>
                            <li><i class="menu-icon fa fa-sign-in"></i><a href="#">City Admin</a></li>
                            <li><i class="menu-icon fa fa-sign-in"></i><a href="#">Zonal Admin</a></li>
                        </ul>
                    </li>

                    <li class="menu-item-has-children dropdown m-bg">
                        <a href="#" class="dropdown-toggle m-clr" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> <i class="menu-icon fa fa-bar-chart"></i>Field Payout</a>
                        <ul class="sub-menu children dropdown-menu">
                            <li><i class="menu-icon fa fa-line-chart"></i><a href="#">Create Field Boy  </a></li>
                            <li><i class="menu-icon fa fa-area-chart"></i><a href="#">Field Payout Reminder</a></li>
                            <li><i class="menu-icon fa fa-pie-chart"></i><a href="#">Payout  Status</a></li>
                            <li><i class="menu-icon fa fa-pie-chart"></i><a href="#">Field Progress Report</a></li>
                        </ul>
                    </li>

                    <li class="menu-item-has-children dropdown m-bg">
                        <a href="#" class="dropdown-toggle m-clr" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> <i class="menu-icon fa fa-bar-chart"></i>Terms & Con.</a>
                        <ul class="sub-menu children dropdown-menu">
                            <li><i class="menu-icon fa fa-line-chart"></i><a href="#">Terms & condition </a></li>
                            <li><i class="menu-icon fa fa-area-chart"></i><a href="#">Privacy Policy</a></li>
                        </ul>
                    </li>

                    <!--<li class="menu-title">Settings</li> --><!-- /.menu-title -->
                    <li class="m-clr">Settings</li>

                    <li class="menu-item-has-children dropdown m-bg">
                        <a href="#" class="dropdown-toggle m-clr" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> <i class="menu-icon fa fa-bar-chart"></i>App Settings</a>
                        <ul class="sub-menu children dropdown-menu">
                            <li><i class="menu-icon fa fa-line-chart"></i><a href="#">Home Screen Settings</a></li>
                            <li><i class="menu-icon fa fa-area-chart"></i><a href="#">Sliders Settings</a></li>
                            <li><i class="menu-icon fa fa-pie-chart"></i><a href="#">App Notifications</a></li>
                        </ul>
                    </li>

                    <li class="menu-item-has-children dropdown m-bg">
                        <a href="#" class="dropdown-toggle m-clr" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> <i class="menu-icon fa fa-bar-chart"></i>Payments</a>
                        <ul class="sub-menu children dropdown-menu">
                            <li><i class="menu-icon fa fa-line-chart"></i><a href="#">Set Payment Gateway</a></li>
                        </ul>
                    </li>

                    <li>
                        <a class="m-clr" href="#"><i class="menu-icon fa fa-th-large"></i>Medias Library</a>
                    </li>

                    <li class="menu-item-has-children dropdown m-bg">
                        <a href="#" class="dropdown-toggle m-clr" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> <i class="menu-icon fa fa-bar-chart"></i>Settings</a>
                        <ul class="sub-menu children dropdown-menu">
                            <li><i class="menu-icon fa fa-line-chart"></i><a href="#">Roles & Permissions</a></li>
                            <li><i class="menu-icon fa fa-line-chart"></i><a href="#">Push Notifications</a></li>
                            <li><i class="menu-icon fa fa-line-chart"></i><a href="#">Mail & SMS API</a></li>
                            <li><i class="menu-icon fa fa-line-chart"></i><a href="#">App Notifications</a></li>
                        </ul>
                    </li>

                </ul>
            </div><!-- /.navbar-collapse -->
        </nav>
    </aside>
    <!-- /#left-panel -->
    <!-- Right Panel -->
    <div id="right-panel" class="right-panel">
        <!-- Header-->
        <header id="header" class="header">
            <div class="top-left">
                <div class="navbar-header">
                    <a class="navbar-brand" href="./"><img src="images/logo.png" alt="Logo"></a>
                    <a class="navbar-brand hidden" href="./"><img src="images/logo2.png" alt="Logo"></a>
                    <a id="menuToggle" class="menutoggle"><i class="fa fa-bars"></i></a>
                </div>
            </div>
            <div class="top-right">
                <div class="header-menu">
                    <div class="header-left">
                        <div class="dropdown for-notification">
                            <button class="btn btn-secondary dropdown-toggle" type="button" id="notification" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <i class="fa fa-bell-o"></i>
                                <span class="count bg-danger">3</span>
                            </button>
                            <div class="dropdown-menu" aria-labelledby="notification">
                                <p class="red">You have 3 Notification</p>
                                <a class="dropdown-item media" href="#">
                                    <i class="fa fa-check"></i>
                                    <p>Server #1 overloaded.</p>
                                </a>
                                <a class="dropdown-item media" href="#">
                                    <i class="fa fa-info"></i>
                                    <p>Server #2 overloaded.</p>
                                </a>
                                <a class="dropdown-item media" href="#">
                                    <i class="fa fa-warning"></i>
                                    <p>Server #3 overloaded.</p>
                                </a>
                            </div>
                        </div>
                    </div>

                    <div class="user-area dropdown float-right">
                        <a href="#" class="dropdown-toggle active" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            <img class="user-avatar rounded-circle" src="images/avter.png" alt="User Avatar">
                            <?php if(Session::has('admin')): ?>
                            <span class="ml-3"><?php echo e(Session::get('admin')['fname']); ?></span>
                            <?php endif; ?>
                        </a>

                        <div class="user-menu dropdown-menu">
                            <a class="nav-link" href="/profile"><i class="fa fa- user"></i>My Profile</a>

                            <a class="nav-link" href="/logout" onclick="ask()"><i class="fa fa-power -off"></i>Logout</a>
                        </div>
                    </div>

                </div>
            </div>
        </header>
        <!-- /#header -->
        <!-- Content -->
        <div class="content">
            <!-- Animated -->
            <div class="animated fadeIn">
                <div class="row">
                    <div class="col-md-6">
                        <h3>Profile</h3>
                        </div>
                        <div class="col-md-6">
                        <nav aria-label="breadcrumb">
                            <ol class="breadcrumb justify-content-end bg-transparent">
                              <li class="breadcrumb-item"><a href="#">Profile</a></li>
                              <!-- <li class="breadcrumb-item active" aria-current="page">Analytics</li> -->
                            </ol>
                          </nav>
                    </div>
                </div>
                <!-- Commission Report  -->
                <div class="row">
                    <div class="col-md-12">
                       <div class="row">
                           <div class="col-md-6">
                               <div class="card">
                                   <div class="card-body c-height">
                                       <div class="profile text-center">
                                           <img src="images/avter.png" alt="" class="img-fluid w-25">
                                           <?php if(Session::has('admin')): ?>
                                           <h4 class="mt-2"><?php echo e(Session::get('admin')['fname']); ?></h4>
                                         
                                           <p><small>LogIn ID: <?php echo e(Session::get('admin')['id']); ?></small></p>
                                       </div>
                                       <div class="profile-text">
                                           <ul>
                                               <li><b>Role :</b> <?php echo e(Session::get('admin')['fname']); ?></li>
                                               <li><b>Phone Number :</b><?php echo e(Session::get('admin')['phn']); ?></li>
                                               <li><b>Email :</b> <?php echo e(Session::get('admin')['email']); ?></li>
                                               <li><b>About Company :</b> Lorem ipsum doloconsectetur </li>
                                           </ul>
                                       </div>
                                       <?php endif; ?>
                                   </div>
                               </div>
                           </div>

                           <div class="col-md-6">
                               <div class="card">
                                   <div class="card-body c-height">
                                    <div class="profile-2">
                                        <form class="f-boy-2">
                                            <div class="row">
                                                <div class="col-md-6">
                                                    <div class="form-group">
                                                        <label>First Name</label>
                                                        <input type="text" class="form-control" value="<?php echo e(Session::get('admin')['fname']); ?>">
                                                        <span></span>
                                                    </div>
                                                </div>
                                                <div class="col-md-6">
                                                    <div class="form-group">
                                                        <label>Last Name</label>
                                                        <input type="text" class="form-control" value="<?php echo e(Session::get('admin')['lname']); ?>">
                                                        <span></span>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col-md-6">
                                                    <div class="form-group">
                                                        <label>Phone Number</label>
                                                        <input type="text" class="form-control" value="<?php echo e(Session::get('admin')['phn']); ?>">
                                                        <span></span>
                                                    </div>
                                                </div>
                                                <div class="col-md-6">
                                                    <div class="form-group">
                                                        <label>Email Address</label>
                                                        <input type="text" class="form-control" value="<?php echo e(Session::get('admin')['email']); ?>">
                                                        <span></span>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col-md-6">
                                                    <div class="form-group">
                                                        <label>Role</label>
                                                        <select class="form-control">
                                                            <option><?php echo e(Session::get('admin')['role']); ?></option>
                                                        </select>
                                                        <span></span>
                                                    </div>
                                                </div>
                                                <div class="col-md-6">
                                                    <div class="form-group">
                                                        <label>City</label>
                                                        <select class="form-control">
                                                            <option><?php echo e(Session::get('admin')['city']); ?></option>
                                                        </select>
                                                        <span></span>
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="row">
                                                <div class="col-md-6">
                                                    <div class="form-group">
                                                        <label>Zone</label>
                                                        <select class="form-control">
                                                            <option><?php echo e(Session::get('admin')['zone']); ?></option>
                                                        </select>
                                                        <span></span>
                                                    </div>
                                                </div>
                                                <div class="col-md-6">
                                                    <div class="form-group">
                                                        <label>Area</label>
                                                        <select class="form-control">
                                                            <option><?php echo e(Session::get('admin')['area']); ?></option>
                                                        </select>
                                                        <span></span>
                                                    </div>
                                                </div>
                                            </div>
                                        </form>
                                    </div>
                                   </div>
                               </div>
                           </div>
                       </div>
                    </div>
                </div>

               

            </div>
            <!-- .animated -->
        </div>
        <!-- /.content -->
    </div>
    <!-- /#right-panel -->

    <!-- Scripts -->
    <script src="https://cdn.jsdelivr.net/npm/jquery@2.2.4/dist/jquery.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.14.4/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.1.3/dist/js/bootstrap.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/jquery-match-height@0.7.2/dist/jquery.matchHeight.min.js"></script>
    <script src="<?php echo e(asset('assets/js/main.js')); ?>"></script>

    <!--  Chart js -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js@2.7.3/dist/Chart.bundle.min.js"></script>

    <!--Chartist Chart-->
    <script src="https://cdn.jsdelivr.net/npm/chartist@0.11.0/dist/chartist.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/chartist-plugin-legend@0.6.2/chartist-plugin-legend.min.js"></script>

    <script src="https://cdn.jsdelivr.net/npm/jquery.flot@0.8.3/jquery.flot.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/flot-pie@1.0.0/src/jquery.flot.pie.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/flot-spline@0.0.1/js/jquery.flot.spline.min.js"></script>

    <script src="https://cdn.jsdelivr.net/npm/simpleweather@3.1.0/jquery.simpleWeather.min.js"></script>
    <script src="<?php echo e(asset('assets/js/init/weather-init.js')); ?>"></script>

    <script src="https://cdn.jsdelivr.net/npm/moment@2.22.2/moment.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/fullcalendar@3.9.0/dist/fullcalendar.min.js"></script>
    <script src="<?php echo e(asset('assets/js/init/fullcalendar-init.js')); ?>"></script>


    <!-- Pagination js -->
    <script>
// selecting required element
const element = document.querySelector(".pagination ul");
let totalPages = 20;
let page = 2;

//calling function with passing parameters and adding inside element which is ul tag
element.innerHTML = createPagination(totalPages, page);
function createPagination(totalPages, page){
  let liTag = '';
  let active;
  let beforePage = page - 1;
  let afterPage = page + 1;
  if(page > 1){ //show the next button if the page value is greater than 1
    liTag += `<li class="btn prev" onclick="createPagination(totalPages, ${page - 1})"><span><i class="fa fa-angle-left"></i> </span></li>`;
  }

  if(page > 2){ //if page value is less than 2 then add 1 after the previous button
    liTag += `<li class="first numb" onclick="createPagination(totalPages, 1)"><span>1</span></li>`;
    if(page > 3){ //if page value is greater than 3 then add this (...) after the first li or page
      liTag += `<li class="dots"><span>...</span></li>`;
    }
  }

  // how many pages or li show before the current li
  if (page == totalPages) {
    beforePage = beforePage - 2;
  } else if (page == totalPages - 1) {
    beforePage = beforePage - 1;
  }
  // how many pages or li show after the current li
  if (page == 1) {
    afterPage = afterPage + 2;
  } else if (page == 2) {
    afterPage  = afterPage + 1;
  }

  for (var plength = beforePage; plength <= afterPage; plength++) {
    if (plength > totalPages) { //if plength is greater than totalPage length then continue
      continue;
    }
    if (plength == 0) { //if plength is 0 than add +1 in plength value
      plength = plength + 1;
    }
    if(page == plength){ //if page is equal to plength than assign active string in the active variable
      active = "active";
    }else{ //else leave empty to the active variable
      active = "";
    }
    liTag += `<li class="numb ${active}" onclick="createPagination(totalPages, ${plength})"><span>${plength}</span></li>`;
  }

  if(page < totalPages - 1){ //if page value is less than totalPage value by -1 then show the last li or page
    if(page < totalPages - 2){ //if page value is less than totalPage value by -2 then add this (...) before the last li or page
      liTag += `<li class="dots"><span>...</span></li>`;
    }
    liTag += `<li class="last numb" onclick="createPagination(totalPages, ${totalPages})"><span>${totalPages}</span></li>`;
  }

  if (page < totalPages) { //show the next button if the page value is less than totalPage(20)
    liTag += `<li class="btn " onclick="createPagination(totalPages, ${page + 1})"><span><i class="fa fa-angle-right"></i></span></li>`;
  }
  element.innerHTML = liTag; //add li tag inside ul tag
  return liTag; //reurn the li tag
}
    </script>
<script>

function ask() {
    
    alert('are you sure you , want to logout ??');
}


</script>
</body>
</html>
<?php /**PATH E:\WebArbiter\CurrentProject\Domzin\admin\resources\views/Profile.blade.php ENDPATH**/ ?>