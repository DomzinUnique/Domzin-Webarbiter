

<?php echo $__env->make('Master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\WebArbiter\CurrentProject\Domzin\admin\resources\views/Dashboard.blade.php ENDPATH**/ ?>