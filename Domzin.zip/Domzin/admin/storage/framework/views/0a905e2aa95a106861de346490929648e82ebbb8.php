<ul class="nav navbar-nav">
                    <form class="px-3 my-4">
                        <input type="search" class="form-control sr-p" placeholder="Search"> <span class="srch"><i class="fa  fa-search"></i></span>
                    </form>
                    <li class="active">
                        <a class="dsh-clr " href="index.html"><i class="menu-icon fa fa-th-large ml-3 text-white"></i>Dashboard </a>
                    </li>
                    <!-- <li class="menu-title">UI elements</li> -->
                    <li class="menu-item-has-children dropdown m-bg  show">
                        <a href="#" class="dropdown-toggle m-clr" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true">
                             <i class="menu-icon fa fa-cogs"></i> Analytics</a>
                        <ul class="sub-menu children dropdown-menu show"><li class="subtitle">
                             <i class="menu-icon fa fa-cogs"></i> Analytics</li>
                            <li><i class="fa fa-puzzle-piece"></i><a href="analytics_commission report.html">Commission Report</a></li>
                            <li><i class="fa fa-id-badge"></i><a href="analytics_progress_data.html">Progress Report</a></li>
                            <li><i class="fa fa-bars"></i><a href="analytics_payout_data.html">Payout Data</a></li>
                        </ul>
                    </li>
                    <li>
                        <a href="activeuserdata.html" class="m-clr"><i class="menu-icon fa fa-th-large"></i>Active User Data</a>
                    </li>

                    <li>
                        <a href="#" class="m-clr"><i class="menu-icon fa fa-th-large"></i>Orders</a>
                    </li>

                    <li class="menu-item-has-children dropdown m-bg">
                        <a href="#" class="dropdown-toggle m-clr" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> <i class="menu-icon fa fa-table"></i>Approvals</a>
                        <ul class="sub-menu children dropdown-menu">
                            <li><i class="fa fa-table"></i><a href="#">Store Approvals</a></li>
                            <li><i class="fa fa-table"></i><a href="#">Products Approvals</a></li>
                            <li><i class="fa fa-table"></i><a href="#">KYC Documents</a></li>
                        </ul>
                    </li>
                    

                    <li>
                        <a class="m-clr" href="#"><i class="menu-icon fa fa-th-large"></i>Support</a>
                    </li>

                    <!-- <li>
                        <a href="#"><i class="menu-icon fa fa-th-large"></i>App Management</a>
                    </li> -->
                    <li class=" m-clr">App Management</li><!-- /.menu-title -->

                    <li class="menu-item-has-children dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> <i class="menu-icon fa fa-tasks"></i>Manage Stores</a>
                        <ul class="sub-menu children dropdown-menu">
                            <li><i class="menu-icon fa fa-fort-awesome"></i><a href="#">Create New Stores</a></li>
                            <li><i class="menu-icon ti-themify-logo"></i><a href="#">Stores Approvals</a></li>
                            <li><i class="menu-icon fa fa-fort-awesome"></i><a href="#">Store Payout History</a></li>
                            <li><i class="menu-icon ti-themify-logo"></i><a href="#">Store Payout Reminder</a></li>
                            <li><i class="menu-icon fa fa-fort-awesome"></i><a href="#">Payout Status</a></li>
                            <li><i class="menu-icon ti-themify-logo"></i><a href="#">Stores Growth Report</a></li>
                        </ul>
                    </li>
                    
                    <li class="menu-item-has-children dropdown m-bg">
                        <a href="#" class="dropdown-toggle m-clr" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> <i class="menu-icon fa fa-bar-chart"></i>Categories</a>
                        <ul class="sub-menu children dropdown-menu">
                            <li><i class="menu-icon fa fa-line-chart"></i><a href="#">Create Category Field</a></li>
                            <li><i class="menu-icon fa fa-area-chart"></i><a href="#">Create Categories</a></li>
                            <li><i class="menu-icon fa fa-pie-chart"></i><a href="#">Create Sub Categories</a></li>
                        </ul>
                    </li>

                    <li class="menu-item-has-children dropdown m-bg">
                        <a href="#" class="dropdown-toggle m-clr" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> <i class="menu-icon fa fa-area-chart"></i>Product</a>
                        <ul class="sub-menu children dropdown-menu">
                            <li><i class="menu-icon fa fa-map-o"></i><a href="#">Add New Product</a></li>
                            <li><i class="menu-icon fa fa-street-view"></i><a href="#">Search  Product</a></li>
                        </ul>
                    </li>
                    
                    <li class="menu-item-has-children dropdown m-bg">
                        <a href="#" class="dropdown-toggle m-clr" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> <i class="menu-icon fa fa-glass"></i>Coupons</a>
                        <ul class="sub-menu children dropdown-menu">
                            <li><i class="menu-icon fa fa-sign-in"></i><a href="#">Create Promocodes</a></li>
                            <li><i class="menu-icon fa fa-sign-in"></i><a href="#">Create Store Offers</a></li>
                        </ul>
                    </li>

                    <li class="menu-item-has-children dropdown m-bg">
                        <a href="#" class="dropdown-toggle m-clr" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> <i class="menu-icon fa fa-glass"></i>Promotions</a>
                        <ul class="sub-menu children dropdown-menu">
                            <li><i class="menu-icon fa fa-sign-in"></i><a href="#">Home Page Banners</a></li>
                            <li><i class="menu-icon fa fa-sign-in"></i><a href="#">Store List Banners</a></li>
                        </ul>
                    </li>

                    <li class="menu-item-has-children dropdown m-bg">
                        <a href="#" class="dropdown-toggle m-clr" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> <i class="menu-icon fa fa-glass"></i>Roles</a>
                        <ul class="sub-menu children dropdown-menu">
                            <li><i class="menu-icon fa fa-sign-in"></i><a href="#">Sub-Admin</a></li>
                            <li><i class="menu-icon fa fa-sign-in"></i><a href="#">City Admin</a></li>
                            <li><i class="menu-icon fa fa-sign-in"></i><a href="#">Zonal Admin</a></li>
                        </ul>
                    </li>

                    <li class="menu-item-has-children dropdown m-bg">
                        <a href="#" class="dropdown-toggle m-clr" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> <i class="menu-icon fa fa-bar-chart"></i>Field Payout</a>
                        <ul class="sub-menu children dropdown-menu">
                            <li><i class="menu-icon fa fa-line-chart"></i><a href="#">Create Field Boy  </a></li>
                            <li><i class="menu-icon fa fa-area-chart"></i><a href="#">Field Payout Reminder</a></li>
                            <li><i class="menu-icon fa fa-pie-chart"></i><a href="#">Payout  Status</a></li>
                            <li><i class="menu-icon fa fa-pie-chart"></i><a href="#">Field Progress Report</a></li>
                        </ul>
                    </li>

                    <li class="menu-item-has-children dropdown m-bg">
                        <a href="#" class="dropdown-toggle m-clr" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> <i class="menu-icon fa fa-bar-chart"></i>Terms &amp; Con.</a>
                        <ul class="sub-menu children dropdown-menu">
                            <li><i class="menu-icon fa fa-line-chart"></i><a href="#">Terms &amp; condition </a></li>
                            <li><i class="menu-icon fa fa-area-chart"></i><a href="#">Privacy Policy</a></li>
                        </ul>
                    </li>

                    <!--<li class="menu-title">Settings</li> --><!-- /.menu-title -->
                    <li class="m-clr">Settings</li>

                    <li class="menu-item-has-children dropdown m-bg">
                        <a href="#" class="dropdown-toggle m-clr" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> <i class="menu-icon fa fa-bar-chart"></i>App Settings</a>
                        <ul class="sub-menu children dropdown-menu">
                            <li><i class="menu-icon fa fa-line-chart"></i><a href="#">Home Screen Settings</a></li>
                            <li><i class="menu-icon fa fa-area-chart"></i><a href="#">Sliders Settings</a></li>
                            <li><i class="menu-icon fa fa-pie-chart"></i><a href="#">App Notifications</a></li>
                        </ul>
                    </li>

                    <li class="menu-item-has-children dropdown m-bg">
                        <a href="#" class="dropdown-toggle m-clr" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> <i class="menu-icon fa fa-bar-chart"></i>Payments</a>
                        <ul class="sub-menu children dropdown-menu">
                            <li><i class="menu-icon fa fa-line-chart"></i><a href="#">Set Payment Gateway</a></li>
                        </ul>
                    </li>

                    <li>
                        <a class="m-clr" href="#"><i class="menu-icon fa fa-th-large"></i>Medias Library</a>
                    </li>

                    <li class="menu-item-has-children dropdown m-bg">
                        <a href="#" class="dropdown-toggle m-clr" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> <i class="menu-icon fa fa-bar-chart"></i>Settings</a>
                        <ul class="sub-menu children dropdown-menu">
                            <li><i class="menu-icon fa fa-line-chart"></i><a href="#">Roles &amp; Permissions</a></li>
                            <li><i class="menu-icon fa fa-line-chart"></i><a href="#">Push Notifications</a></li>
                            <li><i class="menu-icon fa fa-line-chart"></i><a href="#">Mail &amp; SMS API</a></li>
                            <li><i class="menu-icon fa fa-line-chart"></i><a href="#">App Notifications</a></li>
                        </ul>
                    </li>

                </ul><?php /**PATH E:\WebArbiter\CurrentProject\Domzin\admin\resources\views/Leftpanel.blade.php ENDPATH**/ ?>