<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;

class AdminSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('admins')->insert(
        //     [

        //     'fname'=>'Shakti',
        //     'lname'=>'Tomar',
        //     'email'=>'shaktitomar@domzin.ins',
        //     'phn'=>'9657353785',    
        //     'role'=>'Super Admin',  
        //     'city'=>'New Delhi', 
        //     'zone'=>'North Zone', 
        //     'area'=>'Lakshmi Nagar',       
        //     'password'=>Hash::make('12345')
        // ]
        // ,
        [

            'fname'=>'Developer',
            'email'=>'royasutosh7@gmail.com',
            'password'=>Hash::make('12345')



        ]
    );
    }
}
