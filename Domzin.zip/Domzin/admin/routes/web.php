<?php

use Illuminate\Support\Facades\Route;

Route::get('/',[App\Http\Controllers\AdminController::class,'viewLogin']);

Route::post('/auth_check',[App\Http\Controllers\AdminController::class,'check']);

Route::get('/logout',[App\Http\Controllers\AdminController::class,'logout']);

Route::get('/profile',[App\Http\Controllers\AdminController::class,'viewProfile']);

Route::get('/dashboard',[App\Http\Controllers\DashboardController::class,'viewDashboard']);
